    module com.mycompany.iniciosesionjavafx {
    requires javafx.controls;
    requires javafx.fxml;    
    requires java.persistence;
    requires javafx.graphics;
    requires java.logging;

    opens modelo;
    opens metodos;
    opens com.mycompany.iniciosesionjavafx to javafx.fxml;
    exports com.mycompany.iniciosesionjavafx;
}
