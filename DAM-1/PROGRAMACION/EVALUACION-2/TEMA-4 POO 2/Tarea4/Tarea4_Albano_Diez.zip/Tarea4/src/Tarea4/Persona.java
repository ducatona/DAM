
package Tarea4;


public abstract class Persona {

    protected String nombre;
    protected int edad;
    protected double salario;
    
    
    public abstract double calculoSalario();
    
}
