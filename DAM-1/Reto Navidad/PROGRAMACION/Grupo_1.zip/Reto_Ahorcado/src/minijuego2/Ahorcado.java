package minijuego2;
/*CODIGO QUE MUESTRA POR PANTALLA A LA PERSONA PARA MORIR*/
public class Ahorcado {

    public static void fase1() {
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
    }

    public static void fase2() {
        System.out.println("__________ ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
    }

    public static void fase3() {
        System.out.println("__________ ");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
    }

    public static void fase4() {
        System.out.println("__________ ");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|      -------");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
    }

    public static void fase5() {
        System.out.println("__________ ");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|      -------");
        System.out.println("|      |");
        System.out.println("|      |");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
    }

    public static void fase6() {
        System.out.println("__________ ");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|      -------");
        System.out.println("|      | x x |");
        System.out.println("|      |  o  |");
        System.out.println("|      |-----|");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
    }

    public static void fase7() {
        System.out.println("__________ ");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|      -------");
        System.out.println("|      | x x |");
        System.out.println("|      |  o  |");
        System.out.println("|      |-----|");
        System.out.println("|         |   ");
        System.out.println("|         |   ");
        System.out.println("|         |   ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
    }

    public static void fase8() {
        System.out.println("__________ ");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|      -------");
        System.out.println("|      | x x |");
        System.out.println("|      |  o  |");
        System.out.println("|      |-----|");
        System.out.println("|      // |   ");
        System.out.println("|     //  |   ");
        System.out.println("|    //   |   ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
    }

    public static void fase9() {
        System.out.println("__________ ");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|      -------");
        System.out.println("|      | x x |");
        System.out.println("|      |  o  |");
        System.out.println("|      |-----|");
        System.out.println("|      // | \\");
        System.out.println("|     //  |  \\");
        System.out.println("|    //   |   \\");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
        System.out.println("|      ");
    }

    public static void fase10() {
        System.out.println("__________ ");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|      -------");
        System.out.println("|      | x x |");
        System.out.println("|      |  o  |");
        System.out.println("|      |-----|");
        System.out.println("|      // | \\");
        System.out.println("|     //  |  \\");
        System.out.println("|    //   |   \\");
        System.out.println("|       //      ");
        System.out.println("|      //       ");
        System.out.println("|     //        ");
        System.out.println("|    //         ");
    }

    public static void fase11() {
        System.out.println("__________ ");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|      -------");
        System.out.println("|      | x x |");
        System.out.println("|      |  o  |");
        System.out.println("|      |-----|");
        System.out.println("|      // | \\");
        System.out.println("|     //  |  \\");
        System.out.println("|    //   |   \\");
        System.out.println("|       // \\   ");
        System.out.println("|      //   \\  ");
        System.out.println("|     //     \\ ");
        System.out.println("|    //       \\");
        System.out.println("-------------------");
    }
}
